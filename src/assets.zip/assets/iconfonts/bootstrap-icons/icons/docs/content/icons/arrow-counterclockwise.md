---
title: Arrow counterclockwise
categories:
  - Arrows
tags:
  - arrow
  - left
  - spin
  - turn
  - around
  - round
  - rotate
---

---
title: Check
categories:
  - Alerts, warnings, and signs
tags:
  - checkmark
  - confirm
  - done
---
